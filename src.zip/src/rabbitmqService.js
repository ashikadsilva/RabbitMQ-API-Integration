// import axios from 'axios';

// const USER_REST_API_URL = "http://localhost:8080/api/v1/publish";

// class rabbitmqService {
//   PostMessage(user) {
//     return axios.post(USER_REST_API_URL, user);
//   }
  
// }


// export default new rabbitmqService();