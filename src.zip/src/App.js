import logo from './logo.svg';
import './App.css';
import PostDetails from './components/PostMessage';

function App() {
  return (
    <div className="App">
      <PostDetails/>
    </div>
  );
}

export default App;
